const form = document.getElementById('postForm');
const feed = document.getElementById('feed');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = new FormData(form);
  await fetch('http://localhost:4000/api/posts', {
    method: 'POST',
    body: formData
  });
  form.reset();
  loadPosts();
});

async function loadPosts() {
  const res = await fetch('http://localhost:4000/api/posts');
  const posts = await res.json();
  feed.innerHTML = posts.map(p => `
    <div class="post">
      <h3>${p.username}</h3>
      <p>${p.caption}</p>
      ${p.image ? `<img src="http://localhost:4000${p.image}" />` : ''}
      <p>Likes: ${p.likes}</p>
      <button onclick="likePost(${p.id})">Like</button>
      <input placeholder="Comment..." onkeypress="handleComment(event, ${p.id})">
      <ul>${p.comments.map(c => `<li>${c}</li>`).join('')}</ul>
    </div>
  `).join('');
}

function likePost(id) {
  fetch(`http://localhost:4000/api/posts/${id}/like`, { method: 'POST' }).then(loadPosts);
}

function handleComment(e, id) {
  if (e.key === 'Enter') {
    const comment = e.target.value;
    fetch(`http://localhost:4000/api/posts/${id}/comment`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ comment })
    }).then(() => {
      e.target.value = '';
      loadPosts();
    });
  }
}

loadPosts();