const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

const posts = [];
const upload = multer({ dest: 'uploads/' });

app.post('/api/posts', upload.single('image'), (req, res) => {
  const { username, caption } = req.body;
  const newPost = {
    id: Date.now(),
    username,
    caption,
    image: req.file ? `/uploads/${req.file.filename}` : null,
    likes: 0,
    comments: []
  };
  posts.push(newPost);
  res.json(newPost);
});

app.get('/api/posts', (req, res) => {
  res.json(posts);
});

app.post('/api/posts/:id/like', (req, res) => {
  const post = posts.find(p => p.id == req.params.id);
  if (post) post.likes++;
  res.json(post);
});

app.post('/api/posts/:id/comment', (req, res) => {
  const post = posts.find(p => p.id == req.params.id);
  if (post) post.comments.push(req.body.comment);
  res.json(post);
});

app.listen(4000, () => console.log('Server running on port 4000'));